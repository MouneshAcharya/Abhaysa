package beans;

public class Car {
	
	private static String carName;
	
	public static void setCarName(String carName) {
		Car.carName = carName;
	}
	
	public void prinCar(){
		System.out.println("car name is "+Car.carName);
		
	}
	
}
