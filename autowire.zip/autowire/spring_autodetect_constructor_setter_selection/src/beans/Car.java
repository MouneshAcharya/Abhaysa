package beans;

public class Car {
	
	private Engine engine;
	
	public Car(){
		System.out.println("default constructor");
	}
	
	public Car(Engine engine){
		System.out.println("construction selected by the autodetect");
		this.engine = engine;
	}
	
	public void setEngine(Engine engine) {
		System.out.println("setter selected by the autodetect");
		this.engine = engine;
	}
	
	public void printdata(){
		System.out.println("modelYear of the engine is"+engine.getModelYear());
	}

}
