
public class Engine {
	
	private int modelYear;
	
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}
	
	public int getModelYear() {
		return modelYear;
	}

}
