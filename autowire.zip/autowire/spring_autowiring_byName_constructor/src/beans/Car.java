package beans;

public class Car {

	private Engine engine;
	
	public Car(Engine engine) {
		this.engine = engine;
	}
	
	public void printData(){
		System.out.println("modelyear of the engine is "+engine.getModelYear());
	}
}
