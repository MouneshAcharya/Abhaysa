package beans;


public class CP {
	
	private String username;
	
	private String password;
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	
	public String getUsername() {
		return username;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void printCredential(){
		System.out.println("username is "+username);
		System.out.println("password is "+password);
	}
	
}
