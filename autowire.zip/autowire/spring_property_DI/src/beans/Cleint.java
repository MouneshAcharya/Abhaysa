package beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Cleint {

	public static void main(String[] args) {
		
		ApplicationContext ap = new ClassPathXmlApplicationContext("resource/spring.xml");
		CP cp = (CP)ap.getBean("cp");
		cp.printCredential();

	}

}
