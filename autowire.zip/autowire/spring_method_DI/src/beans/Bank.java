package beans;

public class Bank {
	
	public void withdraw(){
		System.out.println(":withdraw method:");
	}
	
	public void calcInterest(){
		System.out.println("calc interest method");
	}

	public void checkBal(){
		System.out.println("check bal method");
	}
	
}
