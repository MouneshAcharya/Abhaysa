package beans;

import java.lang.reflect.Method;

import org.springframework.beans.factory.support.MethodReplacer;

public class NewCalcInterest implements MethodReplacer{

	@Override
	public Object reimplement(Object o, Method m, Object[] param)
			throws Throwable {
		
		System.out.println("new calc interest method impl ");
		
		return o;
	}
	

}
