import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class ValidationFilter implements Filter {

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		PrintWriter out = res.getWriter();
		
		if(name.equals(""))
		{
			out.print("name is reqyuired");
		}else if(email.equals("")){
			out.print("email is reqyuired");
		}else{
			System.out.println("calling filter");
			chain.doFilter(req, res);
		}
		
		
	}

	@Override
	public void destroy() {
	}

	
}
