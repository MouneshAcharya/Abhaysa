import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class myServlet extends HttpServlet {

		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp)
				throws ServletException, IOException {
			
			String formNo = req.getParameter("fno");
			HttpSession hs = req.getSession();
			
			if(formNo.equals("1")){
				String name = req.getParameter("name");
				String fname = req.getParameter("fname");
				String mname = req.getParameter("mname");
				
				hs.setAttribute("name", name);
				hs.setAttribute("fname", fname);
				hs.setAttribute("mname", mname);
				
				resp.sendRedirect("form2.html");
				
			}
			
			if(formNo.equals("2")){
				String contact = req.getParameter("contact");
				String email = req.getParameter("email");
				String address = req.getParameter("address");
				
				hs.setAttribute("contact", contact);
				hs.setAttribute("email", email);
				hs.setAttribute("address", address);
				
				resp.sendRedirect("form3.html");
				
			}
			
			if(formNo.equals("3")){
				String college = req.getParameter("college");
				String company = req.getParameter("company");
				
				resp.setContentType("text/html");
				PrintWriter out = resp.getWriter();
				
				
				out.print(
				"name is "+hs.getAttribute("name") + "\n"
				+"father name is "+hs.getAttribute("fname")+ "\n"
				+"mother name is "+hs.getAttribute("mname")+ "\n"
				+"contact is "+hs.getAttribute("contact")+ "\n"
				+"email is "+hs.getAttribute("email")+ "\n"
				+"city is "+hs.getAttribute("address")+ "\n"
				+"college is "+college + "\n"
				+"company is "+company);
			}
			
			
		}
}
