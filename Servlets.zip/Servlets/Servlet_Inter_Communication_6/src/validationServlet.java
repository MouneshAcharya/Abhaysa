import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class validationServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		System.out.println("inside the validationServlet before calling valid servlet");
		PrintWriter out = resp.getWriter();
		if(req.getParameter("name").equals("")){
			resp.setContentType("text/html");
			out.print("<html><body><h3>please ente r  the valid value</h3></body></html>");
		}else{
		RequestDispatcher rd = req.getRequestDispatcher("next");
		rd.forward(req, resp);
		System.out.println("inside the validationServlet after calling valid servlet");
		}
	}
	
	
}
