package listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Application Lifecycle Listener implementation class Test1
 *
 */
public class Test1 implements ServletContextListener {

    public Test1() {
    }

    public void contextDestroyed(ServletContextEvent arg0) {
    	System.out.println("context destoy method");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg0) {
    	System.out.println("context init method");
    }
	
}
