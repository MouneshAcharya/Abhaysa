package listeners;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class Test2
 *
 */
public class Test2 implements HttpSessionListener {

    public Test2() {
    }

    public void sessionCreated(HttpSessionEvent arg0) {
    	System.out.println("session created");
    }

    public void sessionDestroyed(HttpSessionEvent arg0) {
    	System.out.println("session destroyed");
    }
	
}
