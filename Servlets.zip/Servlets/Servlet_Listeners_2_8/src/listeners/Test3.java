package listeners;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

/**
 * Application Lifecycle Listener implementation class Test3
 *
 */
public class Test3 implements ServletRequestListener {

    public Test3() {
    }

    public void requestDestroyed(ServletRequestEvent arg0) {
    	System.out.println("request destoyed");
    }
    
    public void requestInitialized(ServletRequestEvent arg0) {
    	System.out.println("request initialized");
    }
	
}
